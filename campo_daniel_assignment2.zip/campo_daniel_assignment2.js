var pokemonMaster = "Daniel", pokemonGoal = 5;
var pokemonCaptured = ["Abra", "Pikachu", "Charmander"];

// Procedure Function
var capturedPokemon = function(pokemonCaptured) {
	if (pokemonCaptured.length == pokemonGoal) {
		console.log("Great! It looks like I've reached my goal of capturing " + pokemonGoal + " Pokemon!");
	}
	
	else {
		console.log("Nice! I've reached my goal of " + pokemonGoal + " Pokemon!");
	}
};

capturedPokemon(pokemonCaptured);

// Boolean Function
var goPokemonHunting = function(goal, captured) {
	var pokemonGoal = goal;
	var pokemonCaptured = captured;
	var goHunting;
	
	if (pokemonCaptured != pokemonGoal) {
		goHunting = true;
		console.log("Do I need to go hunt some more Pokemon? " + goHunting);		
	}
	
	else {
		goHunting = false;
		console.log("Do I need to go hunt some more Pokemon? " + goHunting);
	}
	
	return goHunting;
}
goPokemonHunting(pokemonGoal, pokemonCaptured);


// Number Function
var pokemonLeft = function(pokemonCaptured) {
	var pokemonCapturedTotal = pokemonCaptured.length;
	
	while(pokemonCapturedTotal < pokemonGoal) {
		var pokemonRemaining = pokemonGoal - pokemonCapturedTotal;
		console.log("I've captured a total of " + pokemonCapturedTotal + " Pokemon so I haven't reached my goal.");
		console.log("I have " + pokemonRemaining + " Pokemon left to capture.");
		pokemonCapturedTotal++;
	}
	
	return pokemonCapturedTotal;
}

pokemonLeft(pokemonCaptured);

// String Function
var interestedInPokemon = function(name1, name2) {
	var pokemonFirst = name1, pokemonSecond = name2;
	var pokemonInterestedInList = pokemonFirst + " and a " + pokemonSecond;
	
	console.log("For my remaining two Pokemon I would really love to capture a " + pokemonInterestedInList);
	
	return(pokemonInterestedInList);
	
}

interestedInPokemon("Squirtle", "Bulbasaur")

// Array Function
var pokemonWrapUp = function(captured, addToPokemonList) {
	var addToList = addToPokemonList, 
		pokemonCapturedList = captured,
		pokemonCurrentTotal = pokemonCapturedList.length;
		
		console.log(addToList);
		
	for(currentTotal = pokemonCurrentTotal+1; currentTotal <= 5; currentTotal++) {
		console.log("I would really love to add a " + addToList[currentTotal] + " as my number " + currentTotal + " Pokemon in my roster.");
	}
}
var addToPokemonList = ["Squirtle", "Bulbasaur"];
pokemonWrapUp(pokemonCaptured, addToPokemonList);

